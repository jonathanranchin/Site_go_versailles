1. Mode d'emploi
----------------
Ce package permet l'impression de feuilles de probl�mes et de leurs solutions.
Il ne fonctionne que sous Windows (utilisation d'un contr�le active X). Le d�zippage peut 
se faire dans n'importe quel r�pertoire. Il faut simplement d�zipper en recr�ant 
l'arborescence d'origine.

Le package d�zipp� se compose :

> de la page HTML affiche.htm. C'est celle-ci qu'il faut lancer.
Lors de l'utilisation, il faut r�pondre Oui lorsqu'on demande si on peut utiliser
 le contr�le active X. Le but est seulement de pouvoir lire les fichiers sgf.
On demande de saisir :
	- la feuille de probl�mes souhait�e, � choisir parmi plusieurs th�mes
	- si on souhaite afficher les probl�mes ou la solution
	- la feuille � afficher. Suivant la s�rie, le nombre de pages qui la compose 
	  peut varier
Une fois ces param�tres entr�s, le bouton "G�n�rer les diagrammes" affiche sous forme 
de page web la feuille souhait�e. C'est parfois un peu lent, mais javascript n'est pas
connu pour sa rapidit� fulgurante...

Pour l'imprimer, il suffit de choisir l'option d'impression du navigateur. Des r�glages 
peuvent s'av�rer n�cessaires. En effet, les diagrammes sont pr�vus pour �tre affich�s 
en mode portrait et les marges peuvent �ventuellement �tre �largies pour �viter des 
impressions sur deux feuilles au lieu d'une ou des retours � la ligne intempestifs.

> d'un ensemble de fichiers graphiques contenant les dessins du goban et des pierres.
On peut �ventuellement les redessiner, mais il faut conserver le m�me nom. Le jeu actuel 
est pr�vu pour une impression d�cente et avec des fichiers de taille raisonnable. 
L'affichage sur �cran est parfois peu lisible, mais l'obectif premier reste l'impression.

> des s�ries de probl�mes au format sgf, dans les sous-r�pertoires.
N�anmoins, certaines contraintes doivent �tre respect�es pour ne pas avoir de probl�mes
 � l'affichage.



2. Limitations du format sgf
----------------------------
Pour afficher des probl�mes, il n'y avait pas besoin d'une analyse syntaxique compl�te du
format sgf. Les fichiers ici pr�sent sont tous lisibles par un �diteur sgf mais ils doivent
imp�rativement respecter les r�gles suivantes :

- Pas d'arborescence. Une seule solution peut �tre affich�e par probl�me.

- S'il y a plusieurs solutions, il faut l'indiquer dans le commentaire.

- Le probl�me consiste en une s�rie de pierres positionn�es sur le diagramme de d�part 
(codes AW[] et AB[]). 

- La solution consiste en une s�rie de coups nloirs et blancs altern�s. C'est imp�rativement
 � Noir de jouer le premier coup.

- Il ne doit y avoir qu'un seul commentaire. Celui-ci sera affich� sous la solution du 
probl�me. Ce commentaire doit donc �tre tr�s bref pour une mise en page correcte. Dans
ce commentaire, on peut int�grer des tags HTML du moment qu'ils n'interf�rent pas avec ceux 
du graphique. On peut par exemple utiliser <BR> pour les retours � la ligne. En revanche, il 
est d�conseill� d'utiliser des tags de tableaux, etc.
Le commentaire peut �tre plac� � n'importe quel endroit dans le fichier sgf.

- Les marques autoris�es pour la d�finition du probl�me sont les majuscules A � F, et le 
triangle (code TR[]).

- Les marques utilis�es pour la solution sont les minuscules a � f et la marque en croix 
(code MA[]).
Les marques r � x sont r�serv�es � l'affichage de la solution si des pierres sont prises.
Les marques sous forme de lettres doivent �tre positionn�es dans un m�me champ. Donc 
attention, si on veut faire appara�tre des lettres sur le probl�me initial et sur la 
solution, peu importe l'endroit o� on les place mais ils faut que ce soit au m�me endroit, 
sur le probl�me de d�part ou � la fin de la solution.

- le goban doit avoir une taille 19x19. Les limitations de la zone affich�es sont prises 
en compte ailleurs.
- Dans la solution, la gestion des pierres retir�es par capture est prise en charge par 
le programme. Il ne faut donc pas indiquer "1 en 3" dans le commentaire, sinon cette 
information sera affich�e deux fois. Si une pierre a �t� captur�e, le programme se charge 
de marquer ladite pierre. C'est pour cela que les lettres r � x sont r�serv�es.

- La s�quence solution ne comprend que 19 pierres au maximum.

Malgr� ces contraintes, les possibilit�s d'affichage restent tr�s riches...


3. Param�trage d'une nouvelle s�rie
-----------------------------------
Quelques r�gles simples permettent de cr�er une nouvelle s�rie :
- cr�er un nouveau r�pertoire dont le nom est de la forme SerieNNNN, o� NNNN est le num�ro
non pr�fix� par des z�ros.
- dans ce r�pertoire, mettre les fichiers sgf de probl�me (1 par probl�me), nomm�s 
SerieNNNN_ppp, ppp �tant le num�ro de probl�me non pr�fix� par des z�ros.
- Aucun num�ro ne doit �tre omis dans la s�rie.
- Pour d�clarer la s�rie dans le code HTML, il faut aller vers la fin du source et ajouter 
une ligne du type :

<option value='2;Joseki;Facile;11;19;1;8;5;6;12;12;60'>Joseki / facile [2]</option>

La syntaxe est la suivante : des champs s�par�s par des point-virgules.
- 2 : num�ro de la s�rie
- Joseki : Titre qui sera affich� en haut de la page
- Facile : Niveau de difficult� qui sera affich� en haut de la page
- 11; 19 : portion du goban qui sera affich�e pour chaque probl�me (ici 11 en haut, 19 en bas)
- 1; 8 : portion du goban qui sera affich�e pour chaque probl�me (ici 1 � droite, 8 � gauche)
On peut aussi dimensionner automatiquement les probl�mes en laissant faire le programme.
Il suffit d'indiquer un nombre n�gatif ou nul. Par exemple, si on met -1;-1;-1;-1, le probl�me
sera affich� avec une bordure d'une ligne suppl�mentaire par rapport aux symboles plac�s 
sur le goban.
- 5;6; : nombre probl�mes � afficher sur 1 page en lignes (5) et en colonnes (6).
- 12;12 : taille du gif � afficher pour les probl�mes et pour la solution. Cela permet de 
tasser un peu la pr�sentation par exemple pour les probl�mes de fuseki.
- 60 : Nombre de probl�mes de la s�rie. Le premier probl�me doit commencer � 1, et il ne doit 
pas en manquer.
- Joseki / facile [2] : Titre qui appara�t dans la fen�tre d�roulante de s�lection de la 
page web.